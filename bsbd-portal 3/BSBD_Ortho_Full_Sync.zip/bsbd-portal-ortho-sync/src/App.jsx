import React, { useState, useEffect } from 'react'
import { sbGet, sbPost, sbDel, saveSetting } from './lib/supabase'
import { lsGet, lsSet, lsDel, todayStr, userFromRow, userToRow, repProd, repGoal, repColl, getTcAlerts } from './lib/helpers'
import { INIT_PROVIDERS, INIT_STAFF, OFFICES } from './lib/constants'
import { Toast } from './components/ui'

// Pages
import LoginPage     from './pages/Login'
import ModuleHome    from './pages/ModuleHome'
import { ReportsSidebar, TcSidebar } from './pages/Sidebars'
import DashboardPage from './pages/reports/Dashboard'
import AnalyticsPage from './pages/reports/Analytics'
import { buildContext } from './pages/reports/AskAnalytics'
import ManagerFormPage from './pages/reports/Form'
import StaffFormPage   from './pages/reports/StaffForm'
import MorningHuddlePage from './pages/reports/Huddle'
import AdminModule   from './pages/admin/AdminModule'
import ToolsPage     from './pages/tools/Tools'
import TcPatientsPage  from './pages/tc/Patients'
import PredeterminationsPage  from './pages/tc/Predeterminations'
import RidgeviewPortal        from './pages/ridgeview/RidgeviewPortal'
import CollectionTrackerPage from './pages/collections/CollectionTracker'
import OMReviewPage       from './pages/collections/OMReview'
import CollectionsHome    from './pages/collections/CollectionsHome'
import { CollectionsSidebar } from './pages/CollectionsSidebar'
import RecallTrackerPage from './pages/recalls/RecallTracker'
import SuppliesPage      from './pages/supplies/Supplies'
import NoteBuilderPage   from './pages/notes/NoteBuilder'
import CalculatorsTab    from './pages/ridgeview/CalculatorsTab'
import XrayCheckPage     from './pages/notes/XrayCheck'
import OrthoPage         from './pages/ortho/Ortho'
import { countWaiting }  from './lib/notesApi'
import { canOpen }       from './lib/roles'

export default function App() {
  const [ready,    setReady]    = useState(false)
  const [user,     setUser]     = useState(() => {
    try { const s = localStorage.getItem('bsbd_session'); return s ? JSON.parse(s) : null } catch { return null }
  })
  const [page,     setPage]     = useState(() => {
    try { const s = localStorage.getItem('bsbd_session'); if (!s) return 'login'; const u = JSON.parse(s)
      if (u.role==='treatment_coordinator') return 'tc_patients'
      return 'dashboard'
    } catch { return 'login' }
  })
  const [module,   setModule]   = useState(() => {
    try { const s = localStorage.getItem('bsbd_session'); if (!s) return null; const u = JSON.parse(s)
      if (u.role==='treatment_coordinator') return 'tc'
      return null
    } catch { return null }
  })
  const [editReport, setEditReport] = useState(null)
  const [collPage,   setCollPage]   = useState('om_review')

  // Settings
  const [providers,     setProviders]     = useState(INIT_PROVIDERS)
  const [staff,         setStaff]         = useState(INIT_STAFF)
  const [users,         setUsers]         = useState([])
  const [repEmail,      setRepEmail]      = useState('owner@beautifulsmiles.com')
  const [officeEmails,  setOfficeEmails]  = useState({})

  // Data
  const [reports,    setReports]    = useState([])
  const [tcPatients, setTcPatients] = useState([])
  const [collectionPatients, setCollectionPatients] = useState([])
  const [suppliesPending, setSuppliesPending] = useState(0)   // supply orders awaiting approval
  const [notesWaiting, setNotesWaiting] = useState({ count: 0, kind: '' })   // Note Builder: waiting for this dentist, or back to billing
  const [rvView, setRvView] = useState('portal')   // Ridgeview users: their portal, the clinical notes, or the X-ray check

  // Ask Analytics — lifted here so queries survive navigation
  const [askHistory, setAskHistory] = useState([])
  const [askLoading, setAskLoading] = useState(false)

  // UI
  const [toast, setToast] = useState(null)

  // ── Startup ────────────────────────────────────────────────────────────
  useEffect(() => {
    ;(async () => {
      try {
        // Load users from Supabase (always fresh — cross-device login)
        const userRows = await sbGet('users', 'select=*&order=created_at')
        setUsers(userRows.map(userFromRow))

        // Load settings
        const settingRows = await sbGet('settings', 'select=key,value')
        const sm = {}
        settingRows.forEach(r => { sm[r.key] = r.value })
        if (sm.providers)    setProviders(sm.providers)
        if (sm.staff)        setStaff(sm.staff)
        if (sm.email)        setRepEmail(sm.email)
        if (sm.officeEmails) setOfficeEmails(sm.officeEmails)

        // Load reports (cache locally)
        const repRows = await sbGet('reports', 'select=data&order=date.desc')
        const loaded  = repRows.map(r => r.data).filter(Boolean)
        setReports(loaded)
        lsSet('bsbd_reports', loaded)

        // Load TC patients
        try {
          const tcRows = await sbGet('tc_patients', 'select=*&order=updated_at.desc')
          setTcPatients(tcRows)
        } catch {}

        // Supplies orders awaiting approval (badge on the Supplies tile)
        try {
          const so = await sbGet('supply_orders', 'status=eq.submitted&select=id')
          setSuppliesPending(so.length)
        } catch {}

        // Load today's collection patients for TC alert matching
        try {
          const today = new Date().toISOString().split('T')[0]
          const cpRows = await sbGet('collection_patients', `date=eq.${today}&select=patient_name,patient_name_norm,office,operatory,date,total_expected,ins_status,ins_carrier,treatments,flags_total,flags_done,status,amount_collected,balance_bf,collect_override`)
          setCollectionPatients(cpRows)
        } catch {}

      } catch {
        // Fallback to cache
        setReports(lsGet('bsbd_reports', []))
      }
      setReady(true)
    })()
  }, [])

  // Note Builder badge: refresh whenever the module home is showing
  useEffect(() => {
    if (!user || (module !== null && user.role !== 'ridgeview')) return
    countWaiting(user).then(setNotesWaiting)
  }, [user, module])

  const loadSuppliesPending = async () => {
    try { const so = await sbGet('supply_orders', 'status=eq.submitted&select=id'); setSuppliesPending(so.length) } catch {}
  }

  const notify = (msg, type = 'success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 5000)
  }

  // ── Ask Analytics — runs at App level so it survives navigation ─────────
  const askAnalytics = async (questionText) => {
    const text = (questionText || '').trim()
    if (!text || askLoading) return
    setAskLoading(true)
    const entry = { id: Date.now(), question: text, answer: null }
    setAskHistory(h => [...h, entry])
    try {
      const context = buildContext(text, reports, providers, tcPatients)
      const res = await fetch('/api/ai-query', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ question: text, context }),
      })
      const data = await res.json()
      if (!res.ok || data.error) throw new Error(data.error || 'Request failed')
      setAskHistory(h => h.map(e => e.id === entry.id ? { ...e, answer: data.text } : e))
      notify('✅ Analysis ready')
    } catch (e) {
      setAskHistory(h => h.map(e => e.id === entry.id ? { ...e, error: e.message } : e))
      notify('Analysis failed: ' + e.message, 'error')
    }
    setAskLoading(false)
  }
  const clearAskHistory = () => setAskHistory([])

  // ── Settings saves ─────────────────────────────────────────────────────
  const saveProv  = v => { setProviders(v); saveSetting('providers', v) }
  const saveStaff = v => { setStaff(v);     saveSetting('staff', v) }
  const saveEmail = v => { setRepEmail(v);  saveSetting('email', v) }
  const saveOfficeEmails = v => { setOfficeEmails(v); saveSetting('officeEmails', v) }

  // ── User management ────────────────────────────────────────────────────
  const addUser = async newUser => {
    await sbPost('users', userToRow(newUser))
    setUsers(prev => [...prev, newUser])
  }
  const updateUser = async updatedUser => {
    // Map camelCase app fields → snake_case DB columns
    const row = {
      id:          updatedUser.id,
      name:        updatedUser.name,
      username:    updatedUser.username,
      password:    updatedUser.password,
      role:        updatedUser.role,
      office:      updatedUser.office || '',
      staff_name:  updatedUser.staffName || updatedUser.staff_name || '',
      updated_at:  new Date().toISOString(),
    }
    await sbPost('users', row, true)
    setUsers(prev => prev.map(u => u.id === updatedUser.id ? userFromRow(row) : u))
  }
  const removeUser = async id => {
    await sbDel('users', `id=eq.${id}`)
    setUsers(prev => prev.filter(u => u.id !== id))
  }

  // ── Reports ────────────────────────────────────────────────────────────
  const saveReports = v => { setReports(v); lsSet('bsbd_reports', v) }
  const upsertReport = async rep => {
    const row = { id: rep.id, date: rep.date, office: rep.office, submitted_by: rep.submittedBy, submitted_at: rep.submittedAt || new Date().toISOString(), data: rep }
    await sbPost('reports', row, true)
    setReports(prev => {
      const exists = prev.find(r => r.id === rep.id)
      const next   = exists ? prev.map(r => r.id === rep.id ? rep : r) : [rep, ...prev]
      lsSet('bsbd_reports', next)
      return next
    })
  }
  const refreshReports = async () => {
    try {
      const rows   = await sbGet('reports', 'select=data&order=date.desc')
      const loaded = rows.map(r => r.data).filter(Boolean)
      setReports(loaded); lsSet('bsbd_reports', loaded)
      notify('Reports refreshed from server')
    } catch { notify('Refresh failed', 'error') }
  }

  // ── TC patients ────────────────────────────────────────────────────────
  const loadTcPatients = async () => {
    try {
      const rows = await sbGet('tc_patients', 'select=*&order=updated_at.desc')
      setTcPatients(rows)
    } catch {}
  }
  const saveTcPatient = async p => {
    const row = { ...p, updated_at: new Date().toISOString() }
    await sbPost('tc_patients', row, true)
    setTcPatients(prev => {
      const ex = prev.find(x => x.id === p.id)
      return ex ? prev.map(x => x.id === p.id ? row : x) : [row, ...prev]
    })
  }
  const deleteTcPatient = async id => {
    await sbDel('tc_patients', `id=eq.${id}`)
    setTcPatients(prev => prev.filter(p => p.id !== id))
  }

  // ── Auth ───────────────────────────────────────────────────────────────
  const doLogin = async (un, pw) => {
    // Always fetch fresh from DB so newly added users are found immediately
    let allUsers = []
    try {
      const rows = await sbGet('users', 'select=*')
      allUsers = rows.map(userFromRow)
      setUsers(allUsers)
    } catch {
      allUsers = users // fallback to cached if DB unreachable
    }
    const u = allUsers.find(x => x.username === un && x.password === pw)
    if (u) {
      setUser(u)
      try { localStorage.setItem('bsbd_session', JSON.stringify(u)) } catch {}
      if (u.role === 'treatment_coordinator') { setModule('tc'); setPage('tc_patients') }
      else { setModule(null); setPage('home') }   // module page: shows only what this role can open
    } else {
      notify('Invalid username or password', 'error')
    }
  }
  const doLogout = () => { try { localStorage.removeItem('bsbd_session') } catch {}; setUser(null); setPage('login'); setEditReport(null); setModule(null) }
  const openEdit = rep => { setEditReport(rep); setPage('form') }

  const goHome      = () => { setModule(null); setPage('home'); loadSuppliesPending() }
  const openModule  = m => {
    setModule(m)
    if (m === 'reports') setPage(isManager ? 'huddle' : 'mySection')
    if (m === 'tc')      setPage('tc_patients')
    if (m === 'collections') setCollPage(isManager ? 'om_review' : 'collection_tracker')   // front desk can't open the manager review
    if (m === 'recalls')     setPage('recalls')
    if (m === 'supplies')    setPage('supplies')
    if (m === 'notebuilder') setPage('notebuilder')
    if (m === 'ortho')       setPage('ortho')
  }

  // Payment calculators (ortho / Invisalign / in-house) — open to every role.
  // Matches any sidebar page key containing "calc" (calculators, calculator,
  // ortho_calc …) so a renamed sidebar button can't leave a blank page again.
  const isCalcPage = p => typeof p === 'string' && /calc/i.test(p)

  // ── Loading screen ──────────────────────────────────────────────────────
  if (!ready) {
    return (
      <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 16 }}>
        <div className="spinner" />
        <p style={{ color: '#64748b', fontWeight: 600, fontSize: 14 }}>Loading…</p>
      </div>
    )
  }

  if (!user) return <LoginPage doLogin={doLogin} />
  if (user.role === 'ridgeview') {
    const tab = (key, label, badge) => (
      <button onClick={() => { setRvView(key); if (key === 'portal') countWaiting(user).then(setNotesWaiting) }}
        style={{ border: 0, borderBottom: `3px solid ${rvView === key ? '#C9A84C' : 'transparent'}`, background: 'transparent', color: 'white', fontWeight: 700, fontSize: 13, padding: '10px 14px', cursor: 'pointer' }}>
        {label}{badge > 0 && <span style={{ marginLeft: 8, background: '#f59e0b', color: '#1c1917', fontSize: 11, fontWeight: 800, padding: '2px 8px', borderRadius: 99 }}>{badge} back from dentist</span>}
      </button>
    )
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
        <Toast toast={toast} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: '#1B2A6B', padding: '0 12px', flexShrink: 0 }}>
          {tab('portal', 'Ridgeview portal', 0)}
          {tab('notes', 'Clinical notes', notesWaiting.kind === 'billing' ? notesWaiting.count : 0)}
          {tab('xray', 'X-ray check', 0)}
        </div>
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {rvView === 'portal' && <RidgeviewPortal user={user} notify={notify} doLogout={doLogout}/>}
          {rvView === 'xray'   && <XrayCheckPage notify={notify}/>}
          {rvView === 'notes'  && <NoteBuilderPage user={user} providers={providers} staff={staff} users={users} goHome={() => { setRvView('portal'); countWaiting(user).then(setNotesWaiting) }} notify={notify}/>}
        </div>
      </div>
    )
  }

  // A saved session could point at a module this role can't open: send it home.
  if (module !== null && !canOpen(user.role, module)) { setTimeout(() => setModule(null), 0); return null }

  const isAdmin      = user.role === 'admin'
  const isManager = user.role === 'admin' || user.role === 'manager'
  const isTC      = user.role === 'treatment_coordinator' || isManager
  const tcAlertCount = getTcAlerts(tcPatients, user, isManager).length

  const officeStaff = staff[user.role === 'admin' ? (editReport?.office || user.office) : user.office] || []

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#f1f5f9' }}>
      <Toast toast={toast} />
      {module === null
        ? <ModuleHome user={user} isAdmin={isAdmin} isManager={isManager} isTC={isTC} openModule={openModule} doLogout={doLogout} tcAlertCount={tcAlertCount} suppliesPending={suppliesPending} notesWaiting={notesWaiting} />
        : <>
          {module === 'reports' && <ReportsSidebar user={user} page={page} setPage={p => { if (p === 'admin') { openModule('admin'); return } setPage(p); if (p !== 'form') setEditReport(null) }} goHome={goHome} doLogout={doLogout} isAdmin={isAdmin} isManager={isManager} />}
          {module === 'collections' && <CollectionsSidebar user={user} page={collPage} setPage={setCollPage} goHome={goHome} doLogout={doLogout} isManager={isManager}/>}
          {module === 'tc'      && <TcSidebar      user={user} page={page} setPage={setPage} goHome={goHome} doLogout={doLogout} isManager={isManager} tcAlertCount={tcAlertCount} />}
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {/* Reports module */}
            {module === 'reports' && page === 'huddle'    && isManager  && <MorningHuddlePage reports={reports} providers={providers} tcPatients={tcPatients} users={users} notify={notify} />}
            {module === 'reports' && page === 'dashboard' && isManager  && <DashboardPage reports={reports} providers={providers} users={users} user={user} isManager={isManager} notify={notify} onEdit={openEdit} onRefresh={refreshReports} />}
            {module === 'reports' && page === 'analytics' && isManager  && <AnalyticsPage reports={reports} providers={providers} tcPatients={tcPatients} notify={notify} users={users} user={user} isManager={isManager} onEdit={openEdit} askHistory={askHistory} askLoading={askLoading} onAsk={askAnalytics} onClearAsk={clearAskHistory}/>}
            {module === 'reports' && page === 'form'      && isManager  && <ManagerFormPage key={editReport?.id || 'new'} user={user} providers={providers} users={users} officeStaff={officeStaff} reports={reports} upsertReport={upsertReport} notify={notify} editReport={editReport} onEditDone={() => { setEditReport(null); setPage('dashboard') }} />}
            {module === 'reports' && page === 'mySection' && !isManager && <StaffFormPage user={user} notify={notify} />}
            {module === 'reports' && isCalcPage(page) && <CalculatorsTab user={user} notify={notify} />}
            {/* Admin and Tools: their own modules */}
            {module === 'admin' && isManager && <AdminModule goHome={goHome} providers={providers} saveProv={saveProv} staff={staff} saveStaff={saveStaff} users={users} addUser={addUser} removeUser={removeUser} updateUser={updateUser} email={repEmail} saveEmail={saveEmail} officeEmails={officeEmails} saveOfficeEmails={saveOfficeEmails} notify={notify} />}
            {module === 'tools' && <ToolsPage user={user} notify={notify} goHome={goHome} />}
            {/* Supplies module */}
            {module==='supplies' && <SuppliesPage user={user} isManager={isManager} goHome={goHome} notify={notify}/>}
            {/* Note Builder module */}
            {module==='notebuilder' && <NoteBuilderPage user={user} providers={providers} staff={staff} users={users} goHome={goHome} notify={notify}/>}
            {/* Ortho & TMJ records module */}
            {module==='ortho' && <OrthoPage user={user} providers={providers} goHome={goHome} notify={notify}/>}
            {/* Recalls module */}
            {module==='recalls' && <RecallTrackerPage user={user} isManager={isManager} goHome={goHome} users={users}/>}
            {/* Collections module */}
            {module==='collections' && collPage==='om_review'          && isManager && <OMReviewPage user={user} isManager={isManager}/>}
            {module==='collections' && collPage==='collection_tracker' && <CollectionTrackerPage user={user} isManager={isManager}/>}
            {module==='collections' && isCalcPage(collPage) && <CalculatorsTab user={user} notify={notify} />}
            {/* TC module */}
            {module === 'tc' && (page === 'tc_patients' || page === 'tc_analytics') && isTC && <TcPatientsPage user={user} tcPatients={tcPatients} collectionPatients={collectionPatients} isManager={isManager} users={users} saveTcPatient={saveTcPatient} loadTcPatients={loadTcPatients} deleteTcPatient={deleteTcPatient} notify={notify} page={page} setPage={setPage} />}
            {module === 'tc' && page === 'tc_predeterminations' && isTC && <PredeterminationsPage user={user} isManager={isManager} tcPatients={tcPatients} users={users}/>}
            {module === 'tc' && isCalcPage(page) && <CalculatorsTab user={user} notify={notify} />}
          </div>
        </>
      }
    </div>
  )
}
