-- Ortho module: private storage for ceph analysis reports.
-- Run once in Supabase → SQL Editor (after ortho_charts_migration.sql).
--
-- Files saved here are the copy with the patient's name / DOB blacked out by staff before upload.
-- The bucket is private: nothing is reachable by public URL; the portal reads files back with its key.
-- PDF and images only, 15 MB cap.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('ortho-files', 'ortho-files', false, 15728640, array['application/pdf', 'image/jpeg', 'image/png'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

-- Same permissive anon access as the portal's tables for now.
-- Replace with per-user policies when Supabase Auth + the BAA are in place.
drop policy if exists "ortho files read"   on storage.objects;
drop policy if exists "ortho files upload" on storage.objects;
drop policy if exists "ortho files delete" on storage.objects;
create policy "ortho files read"   on storage.objects for select to anon using (bucket_id = 'ortho-files');
create policy "ortho files upload" on storage.objects for insert to anon with check (bucket_id = 'ortho-files');
create policy "ortho files delete" on storage.objects for delete to anon using (bucket_id = 'ortho-files');
