-- Ortho module: Orthodontic Diagnostic Record + TMJ Consultation
-- Run once in Supabase → SQL Editor.
--
-- PHI rule: records are keyed by chart # only. Name, DOB, address, phone, email, responsible party and
-- insurance member details are typed in at print time and never stored. The CHECK constraint below makes
-- the database refuse any row whose data still contains one of those fields.

create table if not exists public.ortho_charts (
  id          text primary key,                         -- generated client-side, like the other portal tables
  form_type   text not null check (form_type in ('ortho', 'tmj')),
  chart_no    text not null,
  office      text,
  dentist     text,
  record_date date default current_date,
  status      text not null default 'draft' check (status in ('draft', 'complete')),
  data        jsonb not null default '{}'::jsonb,
  created_by  text,
  updated_by  text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint ortho_charts_no_phi check (not (data ?| array[
    'pt_first','pt_last','pt_mi','pt_pref','pt_dob','pt_addr','pt_city','pt_state','pt_zip','pt_home','pt_cell','pt_email',
    'rp_name','rp_addr','rp_city','rp_state','rp_zip','rp_employer','rp_phone',
    'ins1_emp','ins1_holder','ins1_addr','ins1_group','ins1_id','ins1_dob',
    'ins2_emp','ins2_holder','ins2_addr','ins2_group','ins2_id','ins2_dob'
  ]))
);

create index if not exists ortho_charts_chart_no_idx on public.ortho_charts (chart_no);
create index if not exists ortho_charts_office_idx   on public.ortho_charts (office, updated_at desc);

create or replace function public.ortho_charts_touch() returns trigger language plpgsql as $$
begin new.updated_at := now(); return new; end $$;

drop trigger if exists ortho_charts_touch on public.ortho_charts;
create trigger ortho_charts_touch before update on public.ortho_charts
  for each row execute function public.ortho_charts_touch();

-- Same permissive anon access as the other portal tables for now.
-- Replace with real per-user policies when Supabase Auth + the BAA are in place.
alter table public.ortho_charts enable row level security;
drop policy if exists ortho_charts_anon_all on public.ortho_charts;
create policy ortho_charts_anon_all on public.ortho_charts for all to anon using (true) with check (true);
